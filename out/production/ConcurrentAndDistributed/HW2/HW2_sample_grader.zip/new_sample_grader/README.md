
THESE TESTS ARE NOT COMPREHENSIVE!!! YOU ARE RESPONSIBLE FOR MAKING SURE YOUR PROGAMS WORK

To run copy your zip submission into the "submissions" folder, and execute run.sh
Make sure that run.sh has execute permissions. To do this type -
chmod +x run.sh
