#!/bin/bash

DIR="$( cd "$( dirname "${BASH_SOURCE[0 ]}" )" && pwd )"
SUBMISSIONS=${DIR}/submissions
JUNIT="$(find /usr/share/java -name "junit4.jar")"

TESTCLASSES=(testCyclicBarrier testMonitorCyclicBarrier testBathroom testPriorityQueue)

testCyclicBarrier_tests=(equalPartyNumThreads)
testMonitorCyclicBarrier_tests=(equalPartyNumThreads)
testBathroom_tests=(capacity)
testPriorityQueue_tests=(serialAdd serialSearch serialGetFirst) 


function run_test {
  timeout 60 java -cp $JUNIT:. Executor $1\#$2

  rt=$?

  return $rt
}

function echo_preamble {
  printf "Students: %s\n\n" "$(basename $(pwd))"
  printf "Sample HW2 Grading Script\n\n"
}

function echo_header {
  printf "\n=================== %s ===================\n" "$1"
}

cd $SUBMISSIONS
SUBDIR=$(pwd)
for i in *.zip; do unzip "$i" -d "${i%%.zip}"; done
rm *.zip

for submission in `find $SUBMISSIONS -type d`; do
  cd $submission
  if [ "$(pwd)" == "$SUBDIR" ]; then
    continue
  fi

  echo_preamble
  
  cp $DIR/grader_pkg/* .
  timeout 60 javac -cp $JUNIT:. *.java
  
  if [ $? -ne 0 ]; then
    echo "COMPILE: FAILED"
    continue
  else
    echo "COMPILE: PASSED"
  fi

  suffix=_test
  assuffix=_tests
  for class in "${TESTCLASSES[@]}"; do
    echo_header $class
    array="$class"_tests[@]
    for routine in "${!array}"; do
      run_test $class $routine$suffix
      if [ $? -ne 0 ]; then
        echo "$routine: FAILED"
      else
        echo "$routine: PASSED"
      fi
    done
  done
done
