package paxos;

public enum State {
    Decided,
    Pending,
    Forgotten
}
